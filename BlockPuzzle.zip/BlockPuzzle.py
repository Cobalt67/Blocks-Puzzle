from tkinter import *

class movingBlock:

    def __init__(self):
        self.window = Tk()
        
        self.window.title("Block Puzzle")
        
        self.window.geometry("500x400")

        self.canvas1 = Canvas(self.window, width = 500, height = 500, bg = "grey")
        self.canvas1.pack(pady=25)
        self.my_image1 = PhotoImage(file="./cube_red.png")
        self.canvas1.create_image(100, 100, anchor = NW, image=self.my_image1,tags="image1")
        self.my_image2 = PhotoImage(file="./cube_blue.png")
        self.canvas1.create_image(50, 50, anchor = NW, image=self.my_image2,tags="image2")
        self.my_image3 = PhotoImage(file="./cube_yellow.png")
        self.canvas1.create_image(200, 300, anchor = NW, image=self.my_image3,tags="image3")
        self.my_image4 = PhotoImage(file="./cube4_yellow.png")
        self.canvas1.create_image(200, 200, anchor = NW, image=self.my_image4,tags="image4")
        
        self.window.bind("<ButtonPress-1>", self.start_move)
        
        self.window.bind("<B1-Motion>", self.move)

        self.window.mainloop()


    def start_move(self, event):
        self._x = event.x
        self._y = event.y


    def move(self, event):
        delta_x = event.x - self._x
        delta_y = event.y - self._y
        self._x = event.x
        self._y = event.y
        if self._x > 0 and self._y > 0:
            self.canvas1.move("current", delta_x, delta_y)
            print('x=',self._x,'y=',self._y, ' event_x=',event.x,' event_y=',event.y,' deltax',delta_x,' deltay=',delta_y)

        print(self.canvas1.gettags("current")[0])
        print('coords:',self.canvas1.coords(self.canvas1.gettags("current")[0]))


        #if self.canvas1.coords(self.canvas1.gettags("current")[0])[0] > 0 and  self.canvas1.coords(self.canvas1.gettags("current")[0])[0] <=50:
        #    self.canvas1.move("current", self.canvas1.coords(self.canvas1.gettags("current")[0])[0]-0, deltay) 
   

movingBlock()

