from tkinter import *

class movingBlock:

    def __init__(self):
        self.window = Tk()
        
        self.window.title("Block Puzzle")
        
        self.window.geometry("601x601")

        self.canvas1 = Canvas(self.window, width = 700, height = 700, bg = "grey")
        self.canvas1.pack(pady=25)
        self.my_image0 = PhotoImage(file="./chess_board.png")
        self.canvas1.create_image(0,0, anchor = NW, image=self.my_image0,tags="image0")
        self.my_image1 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(30,375, anchor = NW, image=self.my_image1,tags="image1")
        self.my_image2 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(90, 375, anchor = NW, image=self.my_image2,tags="image2")
        self.my_image3 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(150, 375, anchor = NW, image=self.my_image3,tags="image3")
        self.my_image4 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(210, 375, anchor = NW, image=self.my_image4,tags="image4")
        self.my_image5 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(270, 375, anchor = NW, image=self.my_image5,tags="image5")
        self.my_image6 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(330, 375, anchor = NW, image=self.my_image6,tags="image6")
        self.my_image7 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(390, 375, anchor = NW, image=self.my_image7,tags="image7")
        self.my_image8 = PhotoImage(file="./infantry1.png")
        self.canvas1.create_image(450, 375, anchor = NW, image=self.my_image8,tags="image8")
        self.my_image9 = PhotoImage(file="./rook1.png")
        self.canvas1.create_image(30, 435, anchor = NW, image=self.my_image9,tags="image9")
        self.my_image10 = PhotoImage(file="./rook1.png")
        self.canvas1.create_image(450, 435, anchor = NW, image=self.my_image10,tags="image10")
        self.my_image11 = PhotoImage(file="./horce1.png")
        self.canvas1.create_image(90, 435, anchor = NW, image=self.my_image11,tags="image11")
        self.my_image12 = PhotoImage(file="./horce1.png")
        self.canvas1.create_image(390, 435, anchor = NW, image=self.my_image12,tags="image12")
        self.my_image13 = PhotoImage(file="./officer1.png")
        self.canvas1.create_image(140, 435, anchor = NW, image=self.my_image13,tags="image13")
        self.my_image14 = PhotoImage(file="./officer1.png")
        self.canvas1.create_image(330, 435, anchor = NW, image=self.my_image14,tags="image14")
        self.my_image15 = PhotoImage(file="./queen1.png")
        self.canvas1.create_image(200, 435, anchor = NW, image=self.my_image15,tags="image15")
        self.my_image16 = PhotoImage(file="./king1.png")
        self.canvas1.create_image(270, 435, anchor = NW, image=self.my_image16,tags="image16")                                  
        self.my_image17 = PhotoImage(file="./rook2.png")
        self.canvas1.create_image(20, 15, anchor = NW, image=self.my_image17,tags="image17")
        self.my_image18 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(20,75 , anchor = NW, image=self.my_image18,tags="image18")
        self.my_image19 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(80, 75, anchor = NW, image=self.my_image19,tags="image19")
        self.my_image20 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(140, 75, anchor = NW, image=self.my_image20,tags="image20")
        self.my_image21 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(200, 75, anchor = NW, image=self.my_image21,tags="image21")
        self.my_image22 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(260,75, anchor = NW, image=self.my_image22,tags="image22")
        self.my_image23 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(320, 75, anchor = NW, image=self.my_image23,tags="image23")
        self.my_image24 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(380,75, anchor = NW, image=self.my_image24,tags="image24")
        self.my_image25 = PhotoImage(file="./infantry2.png")
        self.canvas1.create_image(440, 75, anchor = NW, image=self.my_image25,tags="image25")
        self.my_image26 = PhotoImage(file="./rook2.png")
        self.canvas1.create_image(440, 15, anchor = NW, image=self.my_image26,tags="image26")
        self.my_image27 = PhotoImage(file="./horce2.png")
        self.canvas1.create_image(80, 15, anchor = NW, image=self.my_image27,tags="image27")
        self.my_image28 = PhotoImage(file="./horce2.png")
        self.canvas1.create_image(385, 15, anchor = NW, image=self.my_image28,tags="image28")
        self.my_image29 = PhotoImage(file="./officer2.png")
        self.canvas1.create_image(140, 15, anchor = NW, image=self.my_image29,tags="image29")
        self.my_image30 = PhotoImage(file="./officer2.png")
        self.canvas1.create_image(325, 15, anchor = NW, image=self.my_image30,tags="image30")
        self.my_image31 = PhotoImage(file="./queen2.png")
        self.canvas1.create_image(200, 15, anchor = NW, image=self.my_image31,tags="image31")
        self.my_image32 = PhotoImage(file="./king2.png")
        self.canvas1.create_image(260, 15, anchor = NW, image=self.my_image32,tags="image32")
        
        
        self.window.bind("<ButtonPress-1>", self.start_move)
        
        self.window.bind("<B1-Motion>", self.move)

        self.window.mainloop()


    def start_move(self, event):
        if self.canvas1.gettags("current")[0]!="image0":
            self._x = event.x
            self._y = event.y


    def move(self, event):
        if self.canvas1.gettags("current")[0]!="image0":
            delta_x = event.x - self._x
            delta_y = event.y - self._y
            self._x = event.x
            self._y = event.y
            if self._x > 0 and self._y > 0:
                self.canvas1.move("current", delta_x, delta_y)
                print('x=',self._x,'y=',self._y, ' event_x=',event.x,' event_y=',event.y,' deltax',delta_x,' deltay=',delta_y)

            print(self.canvas1.gettags("current")[0])
            print('coords:',self.canvas1.coords(self.canvas1.gettags("current")[0]))


            #if self.canvas1.coords(self.canvas1.gettags("current")[0])[0] > 0 and  self.canvas1.coords(self.canvas1.gettags("current")[0])[0] <=50:
            #    self.canvas1.move("current", self.canvas1.coords(self.canvas1.gettags("current")[0])[0]-0, deltay) 
       

movingBlock()

